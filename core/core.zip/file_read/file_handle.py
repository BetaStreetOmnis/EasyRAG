import os
import re
import docx
import fitz  # PyMuPDF
import markdown
from bs4 import BeautifulSoup
import traceback
from typing import List, Dict, Any, Tuple
from PIL import Image
import pptx # python-pptx
import pdfplumber # pip install pdfplumber
import sys
import subprocess
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from core.file_read.ocr_extract import extract_text_with_easyocr, extract_text_with_subprocess


"""create by haozi
    2025-03-14
    文件处理类，支持从不同格式的文件中提取内容
"""


class FileHandler:
    """文件处理类，支持从不同格式的文件中提取内容"""
    
    def __init__(self):
        """初始化文件处理器"""
        pass
    
    def process_file(self, file_path: str) -> Dict[str, Any]:
        """
        处理文件并返回提取的文本内容及文件结构
        
        参数:
            file_path (str): 文件路径
            
        返回:
            Dict[str, Any]: 包含文本内容和结构信息的字典
        """
        try:
            file_ext = os.path.splitext(file_path)[1].lower()
            file_name = os.path.basename(file_path)
            
            result = {
                "file_name": file_name,
                "file_path": file_path,
                "file_type": file_ext.replace('.', ''),
                "content": "",
                "structure": {},
                "paragraphs": []  # 添加段落结构
            }
            
            if file_ext == '.txt':
                result["content"] = self._read_text_file(file_path)
                result["paragraphs"] = self._split_into_paragraphs(result["content"])
            elif file_ext == '.docx':
                content, structure = self._read_docx_file(file_path)
                result["content"] = content
                result["structure"] = structure
                result["paragraphs"] = self._split_into_paragraphs(content)
            elif file_ext == '.pdf':
                content, structure = self._read_pdf_file(file_path)
                result["content"] = content
                result["structure"] = structure
                result["paragraphs"] = self._split_into_paragraphs(content)
            elif file_ext in ['.md', '.markdown']:
                content, structure = self._read_markdown_file(file_path)
                result["content"] = content
                result["structure"] = structure
                result["paragraphs"] = self._split_into_paragraphs(content)
            elif file_ext in ['.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.gif']:
                result["content"] = self._read_image_file(file_path)
                result["paragraphs"] = self._split_into_paragraphs(result["content"])
            elif file_ext in ['.ppt', '.pptx']:
                content, structure = self._read_ppt_file(file_path)
                result["content"] = content
                result["structure"] = structure
                result["paragraphs"] = self._split_into_paragraphs(content)
            else:
                raise ValueError(f"不支持的文件格式: {file_ext}")
            
            return result
            
        except Exception as e:
            print(f"处理文件时出错: {str(e)}")
            traceback.print_exc()
            return {
                "file_name": os.path.basename(file_path),
                "file_path": file_path,
                "file_type": os.path.splitext(file_path)[1].lower().replace('.', ''),
                "content": "",
                "structure": {},
                "paragraphs": [],
                "error": str(e)
            }
    
    def _split_into_paragraphs(self, text: str) -> List[Dict[str, Any]]:
        """
        将文本内容分割成段落结构，确保表格和图片与其上下文保持在一起
        
        参数:
            text (str): 要分割的文本内容
            
        返回:
            List[Dict[str, Any]]: 段落列表，每个段落包含内容和位置信息
        """
        paragraphs = []
        
        # 第一步：检测所有表格和图片位置
        table_pattern = re.compile(r'\n表格\s+\d+:[\s\S]+?(?=\n\n表格\s+\d+:|$)')
        image_pattern = re.compile(r'\n插图开始[\s\S]+?插图结束\n')
        
        table_matches = list(table_pattern.finditer(text))
        image_matches = list(image_pattern.finditer(text))
        
        # 收集所有特殊块的位置（表格和图片）
        special_blocks = []
        for m in table_matches:
            special_blocks.append(("table", m.start(), m.end()))
        for m in image_matches:
            special_blocks.append(("image", m.start(), m.end()))
        
        # 按照在文档中的位置排序
        special_blocks.sort(key=lambda x: x[1])
        
        # 第二步：查找这些特殊块的上下文段落
        context_blocks = []
        
        # 确定段落边界
        all_paragraphs = re.split(r'\n\s*\n', text)
        paragraph_positions = []
        
        pos = 0
        for para in all_paragraphs:
            start = pos
            end = pos + len(para)
            if para.strip():  # 只记录非空段落
                paragraph_positions.append((start, end))
            pos = end + 2  # +2 是为了考虑分隔符 \n\n
        
        # 为每个特殊块找到其上下文段落
        for block_type, block_start, block_end in special_blocks:
            # 查找块前的相关段落作为上下文
            context_start = 0
            for para_start, para_end in paragraph_positions:
                if para_end < block_start and para_end > context_start:
                    # 检查段落是否与特殊块相关
                    para_text = text[para_start:para_end]
                    
                    # 表格相关：包含"表"字或距离较近
                    if block_type == "table" and ("表" in para_text or (block_start - para_end) < 100):
                        context_start = para_start
                    
                    # 图片相关：包含"图"字或"如下所示"等描述性词语或距离较近
                    elif block_type == "image" and ("图" in para_text or 
                                                  "如下所示" in para_text or 
                                                  "示意图" in para_text or
                                                  (block_start - para_end) < 100):
                        context_start = para_start
            
            if context_start > 0:
                context_blocks.append((context_start, block_end, block_type))
            else:
                context_blocks.append((block_start, block_end, block_type))
        
        # 合并重叠的上下文块（可能一段文字同时描述了表格和图片）
        merged_blocks = []
        if context_blocks:
            # 按起始位置排序
            context_blocks.sort(key=lambda x: x[0])
            current_block = context_blocks[0]
            
            for next_start, next_end, next_type in context_blocks[1:]:
                curr_start, curr_end, curr_type = current_block
                
                # 如果有重叠，合并块
                if next_start <= curr_end:
                    current_block = (curr_start, max(curr_end, next_end), f"{curr_type}_{next_type}")
                else:
                    merged_blocks.append(current_block)
                    current_block = (next_start, next_end, next_type)
            
            merged_blocks.append(current_block)
        
        # 第三步：处理常规文本和特殊块
        processed_ranges = []
        for start, end, block_type in merged_blocks:
            processed_ranges.append((start, end))
        
        # 处理未被特殊块覆盖的文本
        pos = 0
        while pos < len(text):
            # 检查当前位置是否已处理
            inside_processed = False
            for start, end in processed_ranges:
                if start <= pos < end:
                    inside_processed = True
                    pos = end
                    break
            
            if inside_processed:
                continue
            
            # 找到下一个已处理区域
            next_start = len(text)
            for start, end in processed_ranges:
                if start > pos and start < next_start:
                    next_start = start
            
            # 处理这段普通文本
            if next_start > pos:
                segment_text = text[pos:next_start].strip()
                if segment_text:
                    regular_paragraphs = self._process_regular_text(segment_text, pos)
                    paragraphs.extend(regular_paragraphs)
                pos = next_start
        
        # 添加特殊块（表格/图片及其上下文）
        for idx, (start, end, block_type) in enumerate(merged_blocks):
            block_text = text[start:end].strip()
            if block_text:
                # 根据块类型设置不同的标记
                contains_table = "table" in block_type
                contains_image = "image" in block_type
                
                paragraphs.append({
                    "id": f"special_block_{idx}",
                    "content": block_text,
                    "position": start,
                    "length": end - start,
                    "is_heading": False,
                    "heading_level": 0,
                    "contains_table": contains_table,
                    "contains_image": contains_image
                })
        
        # 按位置排序段落
        paragraphs.sort(key=lambda x: x["position"])
        
        return paragraphs
    
    def _process_regular_text(self, text: str, base_position: int = 0) -> List[Dict[str, Any]]:
        """
        处理普通文本（非表格相关）并分割成段落
        
        参数:
            text (str): 要处理的文本
            base_position (int): 文本在原始文档中的起始位置
            
        返回:
            List[Dict[str, Any]]: 处理后的段落列表
        """
        result = []
        raw_paragraphs = re.split(r'\n\s*\n', text)
        
        start_pos = base_position
        for i, para in enumerate(raw_paragraphs):
            if para.strip():  # 忽略空段落
                # 检测是否为标题
                is_heading = False
                heading_level = 0
                header_match = re.match(r'^(#{1,6})\s+(.+)$', para.strip())
                if header_match:
                    is_heading = True
                    heading_level = len(header_match.group(1))
                
                paragraph = {
                    "id": f"p_{start_pos}",
                    "content": para.strip(),
                    "position": start_pos,
                    "length": len(para),
                    "is_heading": is_heading,
                    "heading_level": heading_level if is_heading else 0,
                    "contains_table": False,
                    "contains_image": False  # 添加图片标记
                }
                result.append(paragraph)
            
            start_pos += len(para) + 2  # +2 是为了考虑分隔符 \n\n
        
        return result
    
    def _read_text_file(self, file_path: str) -> str:
        """读取文本文件"""
        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read()
    
    def _read_docx_file(self, file_path: str) -> Tuple[str, Dict]:
        """
        读取Word文档
        
        返回:
            Tuple[str, Dict]: 文本内容和文档结构
        """
        doc = docx.Document(file_path)
        content = []
        structure = {
            "sections": [],
            "paragraphs": len(doc.paragraphs),
            "tables": len(doc.tables)
        }
        
        current_section = None
        
        for i, para in enumerate(doc.paragraphs):
            content.append(para.text)
            
            # 检测标题
            if para.style.name.startswith('Heading'):
                level = int(para.style.name.replace('Heading', '')) if para.style.name != 'Heading' else 1
                section = {
                    "title": para.text,
                    "level": level,
                    "index": i
                }
                structure["sections"].append(section)
                current_section = section
        
        # 提取表格内容 - 改进版
        for i, table in enumerate(doc.tables):
            table_content = []
            table_content.append(f"\n表格 {i+1}:")
            
            # 添加表格边界标记
            table_content.append("表格开始")
            
            # 确定表头（假设第一行是表头）
            headers = []
            if len(table.rows) > 0:
                for cell in table.rows[0].cells:
                    headers.append(cell.text.strip())
                
                # 添加表头标记和内容
                table_content.append("表头: " + " | ".join(headers))
            
            # 添加表体标记
            table_content.append("表体:")
            
            # 处理表体内容（从第二行开始）
            for row_idx, row in enumerate(table.rows):
                if row_idx == 0 and headers:  # 跳过已处理的表头
                    continue
            
                # 构建结构化的行数据
                row_data = []
                for col_idx, cell in enumerate(row.cells):
                    # 获取对应的列名
                    col_name = headers[col_idx] if col_idx < len(headers) else f"列{col_idx+1}"
                    cell_value = cell.text.strip()
                    # 以"列名:值"的格式构建
                    row_data.append(f"{col_name}: {cell_value}")
            
                # 添加行数据
                table_content.append("行 " + str(row_idx) + ": " + " | ".join(row_data))
            
            # 添加表格结束标记
            table_content.append("表格结束")
            
            # 将表格内容添加到文档内容中
            content.append("\n".join(table_content))
            content.append("\n")  # 表格后添加空行
        
        # 尝试提取文档中的图片
        try:
            from docx.package import Package
            import zipfile
            import io
            
            # 临时图片保存目录
            temp_dir = "temp_docx_images"
            os.makedirs(temp_dir, exist_ok=True)
            
            # 打开Word文档作为zip包
            document = Package.open(file_path)
            image_parts = []
            
            # 获取图片关系
            for rel in document.main_document_part.rels.values():
                if rel.reltype == 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/image':
                    image_parts.append(rel.target_part)
            
            # 处理每个图片
            for i, img_part in enumerate(image_parts):
                # 保存图片到临时文件
                img_bytes = img_part.blob
                img_name = f"{temp_dir}/img_{i}.png"
                
                with open(img_name, "wb") as f:
                    f.write(img_bytes)
                
                # 使用extract_text_with_subprocess进行OCR处理
                img_text = extract_text_with_subprocess(img_name)
                
                if img_text.strip():
                    # 添加结构化的图片内容
                    image_content = [
                        "\n插图开始",
                        f"文档图片 {i+1}:",
                        f"图片内容: {img_text.strip()}",
                        "插图结束"
                    ]
                    content.append("\n".join(image_content))
                    content.append("\n")
                
                # 清理临时文件
                if os.path.exists(img_name):
                    os.remove(img_name)
            
            # 清理临时目录
            if os.path.exists(temp_dir) and len(os.listdir(temp_dir)) == 0:
                os.rmdir(temp_dir)
            
        except Exception as e:
            print(f"提取Word文档中的图片时出错: {str(e)}")
            # 错误不影响主流程继续
        
        return '\n'.join(content), structure
    
    def _read_pdf_file(self, file_path: str) -> Tuple[str, Dict]:
        """使用pdfplumber提取PDF文本和表格"""
        full_text = ""
        structure = {
            "pages": 0,
            "toc": [],
            "metadata": {},
            "images_count": 0,
            "tables_count": 0
        }
        
        total_tables = 0
        total_images = 0
        
        # 使用pdfplumber打开PDF
        with pdfplumber.open(file_path) as pdf:
            structure["pages"] = len(pdf.pages)
            
            # 逐页处理
            for page_idx, page in enumerate(pdf.pages):
                # 提取页面文本
                page_text = page.extract_text() or ""
                
                # 提取表格
                tables = page.extract_tables()
                total_tables += len(tables)
                
                # 处理每个表格
                for table_idx, table in enumerate(tables):
                    table_text = self._format_table_from_pdfplumber(table, page_idx+1, table_idx+1)
                    page_text += "\n" + table_text + "\n"
                
                # 提取图片并OCR处理
                # 注意：pdfplumber不直接支持图片提取，仍需使用PyMuPDF
                # 这部分代码可以保留原来的PyMuPDF实现
                
                full_text += page_text + "\n\n"
        
        # 使用PyMuPDF获取额外的元数据和图片
        doc = fitz.open(file_path)
        structure["toc"] = doc.get_toc()
        structure["metadata"] = doc.metadata
        structure["tables_count"] = total_tables
        
        # 处理图片 (保留原代码)
        # ...
        
        return full_text, structure
    
    def _format_table_from_pdfplumber(self, table, page_num, table_idx):
        """将pdfplumber提取的表格格式化为文本"""
        table_content = []
        table_content.append(f"\n表格 {page_num}-{table_idx}:")
        table_content.append("表格开始")
        
        # 提取表头 (假设第一行是表头)
        if table and len(table) > 0:
            headers = [str(cell).strip() if cell is not None else "" for cell in table[0]]
            table_content.append("表头: " + " | ".join(headers))
            
            # 处理表体
            table_content.append("表体:")
            for row_idx, row in enumerate(table[1:], 1):
                row_data = []
                for col_idx, cell in enumerate(row):
                    cell_value = str(cell).strip() if cell is not None else ""
                    col_name = headers[col_idx] if col_idx < len(headers) else f"列{col_idx+1}"
                    row_data.append(f"{col_name}: {cell_value}")
                
                table_content.append(f"行 {row_idx}: " + " | ".join(row_data))
        
        table_content.append("表格结束")
        return "\n".join(table_content)
    
    def _read_image_file(self, file_path: str) -> str:
        """读取图片文件并使用OCR提取文本"""
        try:
            # 使用extract_text_with_subprocess进行OCR处理
            text = extract_text_with_subprocess(file_path)
            return f"图片内容:\n{text}"
        except Exception as e:
            print(f"OCR处理图片时出错: {str(e)}")
            return "无法识别图片内容"
    
    def _read_markdown_file(self, file_path: str) -> Tuple[str, Dict]:
        """
        读取Markdown文件并转换为纯文本
        
        返回:
            Tuple[str, Dict]: 文本内容和文档结构
        """
        with open(file_path, 'r', encoding='utf-8') as f:
            md_text = f.read()
        
        # 提取标题结构
        structure = {
            "sections": []
        }
        
        # 查找所有标题
        header_pattern = re.compile(r'^(#{1,6})\s+(.+)$', re.MULTILINE)
        for match in header_pattern.finditer(md_text):
            level = len(match.group(1))
            title = match.group(2)
            position = match.start()
            
            structure["sections"].append({
                "level": level,
                "title": title,
                "position": position
            })
        
        # 将Markdown转换为HTML
        html = markdown.markdown(md_text)
        
        # 使用BeautifulSoup提取纯文本
        soup = BeautifulSoup(html, 'html.parser')
        return soup.get_text(), structure
    
    def _read_ppt_file(self, file_path: str) -> Tuple[str, Dict]:
        """
        读取PPT文件，提取文本和图片内容
        
        返回:
            Tuple[str, Dict]: 文本内容和文档结构
        """
        presentation = pptx.Presentation(file_path)
        content = []
        structure = {
            "slides": len(presentation.slides),
            "has_notes": False,
            "images_count": 0
        }
        
        total_images = 0
        has_notes = False
        
        # 创建临时目录保存图片
        temp_dir = "temp_ppt_images"
        os.makedirs(temp_dir, exist_ok=True)
        
        for slide_num, slide in enumerate(presentation.slides):
            slide_content = [f"\n幻灯片 {slide_num+1}:"]
            
            # 提取标题
            if slide.shapes.title:
                slide_content.append(f"标题: {slide.shapes.title.text}")
            
            # 提取文本内容
            text_content = []
            for shape in slide.shapes:
                if hasattr(shape, "text") and shape.text.strip():
                    text_content.append(shape.text)
            
            if text_content:
                slide_content.append("文本内容:")
                slide_content.extend(text_content)
            
            # 提取备注
            if slide.has_notes_slide and slide.notes_slide.notes_text_frame.text.strip():
                has_notes = True
                slide_content.append(f"备注: {slide.notes_slide.notes_text_frame.text.strip()}")
            
            # 提取图片并进行OCR
            image_count = 0
            for shape in slide.shapes:
                if shape.shape_type == 13:  # MSO_SHAPE_TYPE.PICTURE
                    try:
                        image_count += 1
                        total_images += 1
                        
                        # 保存图片到临时文件
                        img_path = f"{temp_dir}/slide_{slide_num+1}_img_{image_count}.png"
                        with open(img_path, 'wb') as f:
                            f.write(shape.image.blob)
                        
                        # 使用extract_text_with_subprocess进行OCR处理
                        img_text = extract_text_with_subprocess(img_path)
                        
                        if img_text.strip():
                            slide_content.append("\n插图开始")
                            slide_content.append(f"幻灯片图片 {image_count}:")
                            slide_content.append(f"图片内容: {img_text.strip()}")
                            slide_content.append("插图结束")
                        
                        # 删除临时文件
                        if os.path.exists(img_path):
                            os.remove(img_path)
                    except Exception as e:
                        print(f"处理PPT中的图片时出错: {str(e)}")
            
            content.append("\n".join(slide_content))
        
        # 清理临时目录
        if os.path.exists(temp_dir) and len(os.listdir(temp_dir)) == 0:
            os.rmdir(temp_dir)
        
        structure["has_notes"] = has_notes
        structure["images_count"] = total_images
        
        return '\n\n'.join(content), structure

if __name__ == "__main__":
    file_path = r"D:\code\temp_1服务及售后方案 .docx"
    handler = FileHandler()
    result = handler.process_file(file_path)
    print(result)
